import { IResolver, ResolutionContext } from 'cdk8s';
export declare class AwsCdkResolver implements IResolver {
    resolve(context: ResolutionContext): void;
    private findOutput;
    private fetchOutputValue;
}
